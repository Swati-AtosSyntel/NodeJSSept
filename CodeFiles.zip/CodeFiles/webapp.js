var express=require('express');
var app=express();

app.get('/',function(req,res){
    res.send('<html><body><h1>Hello World!!!!</h1></body></html>');

});

app.post('/submitdata',function(req,res){
    res.send('POST request');
})
app.put('/updatedata',function(req,res){
    res.send('PUT request');
});

app.delete('/deletedata',function(req,res){
    res.send('Delete Request');
});

var server=app.listen(5000,function(){
    console.log('Node server is running on port number 5000');
})