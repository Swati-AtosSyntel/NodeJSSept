var events=require('events');
 var em=new events.EventEmitter();

 em.on('CustomEvent',function(data){
     console.log("I am the first subscriber"+data);
 });

 em.addListener('CustomEvent2',function(data){
     console.log("Second Custom event"+data);
 })

 em.emit('CustomEvent',"This is custom event");
 em.emit('CustomEvent2',"This is my second  custom event");