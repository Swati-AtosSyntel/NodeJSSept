var express=require('express');
var app=express();

var fs=require('fs');


app.delete('/deleteUser',function(req,res){
    fs.readFile(__dirname+"/"+"users.json",'utf8',function(err,data){
        users=JSON.parse(data);
        delete users["user" + 1];
        
        res.send(JSON.stringify(users));
    });
})

var server=app.listen(8081,function(){
    var host=server.address().address;
    var port=server.address().port;
    console.log("app listening at http://",host,port);
})