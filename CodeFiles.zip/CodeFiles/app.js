//to read file
 var fs=require('fs');
// fs.readFile("aa.txt",function(err,data){
//     if(err)
//     throw err;
// console.log(data);
// });

//to write file
// fs.writeFile("aa.txt",'Hello World!!!',function(err){
//     if(err)
//     console.log(err);
//     else
//     console.log("Write Operation done");
// });
//to read excel file

// var reader=require('xlsx');
// const file=reader.readFile('./test.xlsx');

// let data=[];

// const sheets=file.SheetNames;

// for(let i=0;i<sheets.length;i++)
// {
//     const temp=reader.utils.sheet_to_json(file.Sheets[file.SheetNames[i]])
//     temp.forEach((res)=>{
//         data.push(res)
//     })
// }
// console.log(data);

//to write data in excel file

var reader=require('xlsx');
const file=reader.readFile('./test.xlsx');
debugger;
let empData=[
    {EmployeeID:178,Employeename:"Nilesh",ManagerID:350,ManagerName:"Nita"}
    
]

const ws=reader.utils.json_to_sheet(empData)
reader.utils.book_append_sheet(file,ws,"Sheet3");
reader.writeFile(file,'./test.xlsx');
